<div class="container regularText">
    <h5>Leading computer, laptop and gaming PC retaile and online shop in Bangladesh</h5>
    <p>Lorem ipsum dollar sit Lorem ipsum dollar sit Lorem ipsum dollar
        sit Lorem ipsum dollar sit Lorem ipsum dollar sit Lorem ipsum dollar sit Lorem ipsum dollar sit Lorem ipsum do
        llar sit Lorem ipsum dollar sit Lorem ipsum dollar sit Lorem ipsum dollar sit Lorem ipsum dollar sit Lorem ipsu
        m dollar sit Lorem ipsum dollar sit Lorem ipsum dollar sit Lorem ipsum dollar sit Lorem ipsum dollar sit Lorem
        ipsum dollar sit Lorem ipsum dollar sit Lorem ipsum dollar sit Lorem ipsum dollar sit Lorem ipsum dollar sit Lo
        rem ipsum dollar sit Lorem ipsum dollar sit Lorem ipsum dollar sit Lorem ipsum dollar sit Lorem ipsum dollar sit </p>
</div>



<footer class="footer">
    <div class="container">
        <div class="row my-3">
            <div class="col-lg-4 col-md-4 col-sm-12">
                <div class="footerItem"><i class="fa-solid fa-envelope"></i>
                    <span>Contact us</span>
                    <p>hellohridoy007@gmail.com</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12">
                <div class="footerItem">
                    <i class="fa-regular fa-heart"></i>
                    <span>Subscribe us</span>
                        <form class="form-inline my-2 my-lg-0 d-flex">
                            <input class="form-control mr-sm-2 w-lg-75 w-md-50" type="search" placeholder="username@email.com" aria-label="Search">
                            <button class="btn my-2 my-sm-0" type="submit">Search</button>
                        </form>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12">
                <div class="footerItem">
                    <i class="fa-solid fa-phone-flip"></i>
                    <span>Hotline</span>
                    <p>01833455467, 01944734348</p>
                </div>
            </div>

        </div>
    </div>
</footer>


{{--Footer Below here--}}
<div class="container">
<div class="row">

    <div class="col-lg-3 col-md-6 col-sm-6">
        <div class="h6 my-3">Address</div>
        <div class="regularText">
            41/1 - c, Bashbari housing, Mohammadpur
            <br>
            Dhaka - 1207, Bangladesh
        </div>
    </div>
    <div class="col-lg-3 col-md-6 col-sm-6">
        <div class="h6 my-3">Social Link</div>
        <div>
            <a href="#"><i class="fa-brands fa-facebook"></i></a>
            <a href="#"><i class="fa-brands fa-twitter"></i></a>
            <a href="#"><i class="fa-brands fa-instagram"></i></a>
            <a href="#"><i class="fa-brands fa-youtube"></i></a>
            <a href="#"><i class="fa-brands fa-linkedin"></i></a>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 col-sm-6">
        <div class="h6 my-3">Hotline</div>
        <div>
            <p class="h5">+880-1714780348</p>
            <p class="h5">+880-1944734348</p>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 col-sm-6">
        <div class="h6 my-3">Email</div>
        <div>
            <p class="h5">mobiledokan@gmail.com</p>
            <p class="h5">mobiledokan@gmail.com</p>
        </div>
    </div>

</div>
    <hr/>

</div>
