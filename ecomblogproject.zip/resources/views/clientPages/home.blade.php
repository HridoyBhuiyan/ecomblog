@extends('index')
@section('content')
    <div class="container my-5">
        <div class="productGrid" id="productGrid">

            <div class="d-flex flex-column shadow-lg">
                <img src="storage/phoneimg.jpg" alt="" class="my-1">
                <span class="mx-2 text-danger cardTitle">Motorola Moto G31 Smartphone (6/128GB)</span>
                <div class="d-flex justify-content-between cardPrice">
                    <div>
                        <span class="mx-2 cardCurrentPrice">23,999$</span>
                        <strike>23,999$</strike>
                    </div>

                    <i class="fa-regular fa-heart"></i>
                    <i class="fa-solid fa-heart"></i>
                </div>
            </div>


            <div class="d-flex flex-column shadow-lg">
                <img src="storage/phoneimg.jpg" alt="" class="my-1">
                <span class="mx-2 text-danger cardTitle">Motorola Moto G31 Smartphone (6/128GB)</span>
                <div class="d-flex justify-content-between cardPrice">
                    <div>
                        <span class="mx-2 cardCurrentPrice">23,999$</span>
                        <strike>23,999$</strike>
                    </div>

                    <i class="fa-regular fa-heart"></i>
                    <i class="fa-solid fa-heart"></i>
                </div>
            </div>




            <div class="d-flex flex-column shadow-lg">
                <img src="storage/phoneimg.jpg" alt="" class="my-1">
                <span class="mx-2 text-danger cardTitle">Motorola Moto G31 Smartphone (6/128GB)</span>
                <div class="d-flex justify-content-between cardPrice">
                    <div>
                        <span class="mx-2 cardCurrentPrice">23,999$</span>
                        <strike>23,999$</strike>
                    </div>

                    <i class="fa-regular fa-heart"></i>
                    <i class="fa-solid fa-heart"></i>
                </div>
            </div>


            <div class="d-flex flex-column shadow-lg">
                <img src="storage/phoneimg.jpg" alt="" class="my-1">
                <span class="mx-2 text-danger cardTitle">Motorola Moto G31 Smartphone (6/128GB)</span>
                <div class="d-flex justify-content-between cardPrice">
                    <div>
                        <span class="mx-2 cardCurrentPrice">23,999$</span>
                        <strike>23,999$</strike>
                    </div>

                    <i class="fa-regular fa-heart"></i>
                    <i class="fa-solid fa-heart"></i>
                </div>
            </div>




            <div class="d-flex flex-column shadow-lg">
                <img src="storage/phoneimg.jpg" alt="" class="my-1">
                <span class="mx-2 text-danger cardTitle">Motorola Moto G31 Smartphone (6/128GB)</span>
                <div class="d-flex justify-content-between cardPrice">
                    <div>
                        <span class="mx-2 cardCurrentPrice">23,999$</span>
                        <strike>23,999$</strike>
                    </div>

                    <i class="fa-regular fa-heart"></i>
                    <i class="fa-solid fa-heart"></i>
                </div>
            </div>


            <div class="d-flex flex-column shadow-lg">
                <img src="storage/phoneimg.jpg" alt="" class="my-1">
                <span class="mx-2 text-danger cardTitle">Motorola Moto G31 Smartphone (6/128GB)</span>
                <div class="d-flex justify-content-between cardPrice">
                    <div>
                        <span class="mx-2 cardCurrentPrice">23,999$</span>
                        <strike>23,999$</strike>
                    </div>

                    <i class="fa-regular fa-heart"></i>
                    <i class="fa-solid fa-heart"></i>
                </div>
            </div>




            <div class="d-flex flex-column shadow-lg">
                <img src="storage/phoneimg.jpg" alt="" class="my-1">
                <span class="mx-2 text-danger cardTitle">Motorola Moto G31 Smartphone (6/128GB)</span>
                <div class="d-flex justify-content-between cardPrice">
                    <div>
                        <span class="mx-2 cardCurrentPrice">23,999$</span>
                        <strike>23,999$</strike>
                    </div>

                    <i class="fa-regular fa-heart"></i>
                    <i class="fa-solid fa-heart"></i>
                </div>
            </div>


            <div class="d-flex flex-column shadow-lg">
                <img src="storage/phoneimg.jpg" alt="" class="my-1">
                <span class="mx-2 text-danger cardTitle">Motorola Moto G31 Smartphone (6/128GB)</span>
                <div class="d-flex justify-content-between cardPrice">
                    <div>
                        <span class="mx-2 cardCurrentPrice">23,999$</span>
                        <strike>23,999$</strike>
                    </div>

                    <i class="fa-regular fa-heart"></i>
                    <i class="fa-solid fa-heart"></i>
                </div>
            </div>




            <div class="d-flex flex-column shadow-lg">
                <img src="storage/phoneimg.jpg" alt="" class="my-1">
                <span class="mx-2 text-danger cardTitle">Motorola Moto G31 Smartphone (6/128GB)</span>
                <div class="d-flex justify-content-between cardPrice">
                    <div>
                        <span class="mx-2 cardCurrentPrice">23,999$</span>
                        <strike>23,999$</strike>
                    </div>

                    <i class="fa-regular fa-heart"></i>
                    <i class="fa-solid fa-heart"></i>
                </div>
            </div>


            <div class="d-flex flex-column shadow-lg">
                <img src="storage/phoneimg.jpg" alt="" class="my-1">
                <span class="mx-2 text-danger cardTitle">Motorola Moto G31 Smartphone (6/128GB)</span>
                <div class="d-flex justify-content-between cardPrice">
                    <div>
                        <span class="mx-2 cardCurrentPrice">23,999$</span>
                        <strike>23,999$</strike>
                    </div>

                    <i class="fa-regular fa-heart"></i>
                    <i class="fa-solid fa-heart"></i>
                </div>
            </div>




            <div class="d-flex flex-column shadow-lg">
                <img src="storage/phoneimg.jpg" alt="" class="my-1">
                <span class="mx-2 text-danger cardTitle">Motorola Moto G31 Smartphone (6/128GB)</span>
                <div class="d-flex justify-content-between cardPrice">
                    <div>
                        <span class="mx-2 cardCurrentPrice">23,999$</span>
                        <strike>23,999$</strike>
                    </div>

                    <i class="fa-regular fa-heart"></i>
                    <i class="fa-solid fa-heart"></i>
                </div>
            </div>


            <div class="d-flex flex-column shadow-lg">
                <img src="storage/phoneimg.jpg" alt="" class="my-1">
                <span class="mx-2 text-danger cardTitle">Motorola Moto G31 Smartphone (6/128GB)</span>
                <div class="d-flex justify-content-between cardPrice">
                    <div>
                        <span class="mx-2 cardCurrentPrice">23,999$</span>
                        <strike>23,999$</strike>
                    </div>

                    <i class="fa-regular fa-heart"></i>
                    <i class="fa-solid fa-heart"></i>
                </div>
            </div>




            <div class="d-flex flex-column shadow-lg">
                <img src="storage/phoneimg.jpg" alt="" class="my-1">
                <span class="mx-2 text-danger cardTitle">Motorola Moto G31 Smartphone (6/128GB)</span>
                <div class="d-flex justify-content-between cardPrice">
                    <div>
                        <span class="mx-2 cardCurrentPrice">23,999$</span>
                        <strike>23,999$</strike>
                    </div>

                    <i class="fa-regular fa-heart"></i>
                    <i class="fa-solid fa-heart"></i>
                </div>
            </div>


            <div class="d-flex flex-column shadow-lg">
                <img src="storage/phoneimg.jpg" alt="" class="my-1">
                <span class="mx-2 text-danger cardTitle">Motorola Moto G31 Smartphone (6/128GB)</span>
                <div class="d-flex justify-content-between cardPrice">
                    <div>
                        <span class="mx-2 cardCurrentPrice">23,999$</span>
                        <strike>23,999$</strike>
                    </div>

                    <i class="fa-regular fa-heart"></i>
                    <i class="fa-solid fa-heart"></i>
                </div>
            </div>




            <div class="d-flex flex-column shadow-lg">
                <img src="storage/phoneimg.jpg" alt="" class="my-1">
                <span class="mx-2 text-danger cardTitle">Motorola Moto G31 Smartphone (6/128GB)</span>
                <div class="d-flex justify-content-between cardPrice">
                    <div>
                        <span class="mx-2 cardCurrentPrice">23,999$</span>
                        <strike>23,999$</strike>
                    </div>

                    <i class="fa-regular fa-heart"></i>
                    <i class="fa-solid fa-heart"></i>
                </div>
            </div>


            <div class="d-flex flex-column shadow-lg">
                <img src="storage/phoneimg.jpg" alt="" class="my-1">
                <span class="mx-2 text-danger cardTitle">Motorola Moto G31 Smartphone (6/128GB)</span>
                <div class="d-flex justify-content-between cardPrice">
                    <div>
                        <span class="mx-2 cardCurrentPrice">23,999$</span>
                        <strike>23,999$</strike>
                    </div>

                    <i class="fa-regular fa-heart"></i>
                    <i class="fa-solid fa-heart"></i>
                </div>
            </div>




            <div class="d-flex flex-column shadow-lg">
                <img src="storage/phoneimg.jpg" alt="" class="my-1">
                <span class="mx-2 text-danger cardTitle">Motorola Moto G31 Smartphone (6/128GB)</span>
                <div class="d-flex justify-content-between cardPrice">
                    <div>
                        <span class="mx-2 cardCurrentPrice">23,999$</span>
                        <strike>23,999$</strike>
                    </div>

                    <i class="fa-regular fa-heart"></i>
                    <i class="fa-solid fa-heart"></i>
                </div>
            </div>


            <div class="d-flex flex-column shadow-lg">
                <img src="storage/phoneimg.jpg" alt="" class="my-1">
                <span class="mx-2 text-danger cardTitle">Motorola Moto G31 Smartphone (6/128GB)</span>
                <div class="d-flex justify-content-between cardPrice">
                    <div>
                        <span class="mx-2 cardCurrentPrice">23,999$</span>
                        <strike>23,999$</strike>
                    </div>

                    <i class="fa-regular fa-heart"></i>
                    <i class="fa-solid fa-heart"></i>
                </div>
            </div>




            <div class="d-flex flex-column shadow-lg">
                <img src="storage/phoneimg.jpg" alt="" class="my-1">
                <span class="mx-2 text-danger cardTitle">Motorola Moto G31 Smartphone (6/128GB)</span>
                <div class="d-flex justify-content-between cardPrice">
                    <div>
                        <span class="mx-2 cardCurrentPrice">23,999$</span>
                        <strike>23,999$</strike>
                    </div>

                    <i class="fa-regular fa-heart"></i>
                    <i class="fa-solid fa-heart"></i>
                </div>
            </div>


            <div class="d-flex flex-column shadow-lg">
                <img src="storage/phoneimg.jpg" alt="" class="my-1">
                <span class="mx-2 text-danger cardTitle">Motorola Moto G31 Smartphone (6/128GB)</span>
                <div class="d-flex justify-content-between cardPrice">
                    <div>
                        <span class="mx-2 cardCurrentPrice">23,999$</span>
                        <strike>23,999$</strike>
                    </div>

                    <i class="fa-regular fa-heart"></i>
                    <i class="fa-solid fa-heart"></i>
                </div>
            </div>







        </div>

        <nav aria-label="Page navigation example">
            <ul class="pagination">
                <li class="page-item"><a class="page-link" href="#">Previous</a></li>
                <li class="page-item"><a class="page-link" href="#">1</a></li>
                <li class="page-item"><a class="page-link" href="#">2</a></li>
                <li class="page-item"><a class="page-link" href="#">3</a></li>
                <li class="page-item"><a class="page-link" href="#">Next</a></li>
            </ul>
        </nav>

    </div>
@endsection


