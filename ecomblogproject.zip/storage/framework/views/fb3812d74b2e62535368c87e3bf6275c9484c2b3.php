<?php $__env->startSection('menuContent'); ?>

    <div>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Products</li>
            </ol>
        </nav>

        <div>
            <div class="btn btn-success"><a href="/admin/add-product" class="text-white"><i class="px-1 fa-solid fa-square-plus"></i>New Product</a></div>
            <div class="btn btn-info"><i class="px-1 fa-solid fa-file"></i>Published</div>
            <div class="btn btn-danger"><i class="px-1 fa-solid fa-circle-pause"></i>Draft</div>
        </div>
        <hr>
        <?php if(session('newProductAdd')): ?>
            <nav aria-label="breadcrumb">
                <div class="breadcrumb text-success">
                    <?php echo e(session('newProductAdd')); ?>

                </div>
            </nav>

        <?php endif; ?>


        <div class="existingPostList">

            <div class="existingPostList">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="breadcrumb d-flex flex-row align-item-center justify-items-center">
                        <div class="w-75">
                            <a href="<?php echo e(route('blogUpdate',[$item->id])); ?>">
                                <?php echo e($item->title); ?>

                            </a>
                            <div class="postInfo row">
                                <div class="col-4">ID :<span> <?php echo e($item->id); ?> </span></div>
                                <div class="col-4">Date : <span><?php echo e(substr($item->created_at, 0, 10)); ?></span></div>
                                <?php if($item->status=="draft"): ?>
                                    <div class="col-4">Status :  <span class="text-danger">Draft</span></div>
                                <?php elseif($item->status=="published"): ?>
                                    <div class="col-4">Status :  <span class="text-success">Published</span></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="w-25 d-flex flex-row align-item-center justify-content-between" style="align-items: center">

                            <form action="<?php echo e(route('deletePost',[$item->id])); ?>" method="GET">
                                <button type="submit" class="btn bg-danger text-white btnInline mx-1"><i class="px-1 fa-solid fa-trash"></i>Delete</button>
                            </form>

                            <form action="<?php echo e(route('blogUpdate',[$item->id])); ?>" method="GET">
                                <button class="btn bg-dark text-white btnInline mx-1"><i class="px-1 fa-solid fa-circle-pause"></i>Edit</button>
                            </form>

                        </div>
                    </div>


                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



            </div>


        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hridoy\Desktop\Rashik vai\ecomblogproject\resources\views/adminPage/product/product.blade.php ENDPATH**/ ?>