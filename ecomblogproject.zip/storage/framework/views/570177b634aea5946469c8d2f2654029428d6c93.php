<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="row">
                <div class="pt-1 col-2 bg-white menuItem">
                    <ul>
                        <li class="my-2 py-2 rounded" style="padding-left: 10px">
                            <a href="/admin/summery">
                                Summery
                            </a>
                        </li>
                        <li class="my-2 py-2 rounded" style="padding-left: 10px">
                            <a href="/admin/product">Product Post</a>
                        </li>
                        <li class="my-2 py-2 rounded" style="padding-left: 10px">
                            <a href="/admin/blog">Blog Post</a>
                        </li>
                        <li class="my-2 py-2 rounded" style="padding-left: 10px">
                            <a href="/admin/blog">Media</a>
                        </li>
                        <li class="my-2 py-2 rounded" style="padding-left: 10px">
                            <a href="/admin/category">Category</a>
                        </li>
                        <li class="my-2 py-2 rounded" style="padding-left: 10px">
                            <a href="/admin/category">Tags</a>
                        </li>
                        <li class="my-2 py-2 rounded" style="padding-left: 10px">
                            <a href="/admin/footer">Footer</a>
                        </li>
                        <li class="my-2 py-2 rounded" style="padding-left: 10px">
                            <a href="/admin/add">New Admin</a>
                        </li>
                        <li class="my-2 py-2 rounded" style="padding-left: 10px">
                            <a href="/admin/meta">SEO Meta</a>
                        </li>
                        <li class="my-2 py-2 rounded" style="padding-left: 10px">
                            <a href="/admin/info">Site Info</a>
                        </li>
                    </ul>
                </div>
                <div class="col-10">


                    <?php echo $__env->yieldContent('menuContent'); ?>


                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Hridoy\Desktop\Rashik vai\ecomblogproject\resources\views/dashboard.blade.php ENDPATH**/ ?>